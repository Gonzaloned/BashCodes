#!/bin/bash
arreglo=(3 4 5)
echo ${arreglo[*]}
arreglo+=(6)
echo ${arreglo[*]}