#!/bin/bash
echo los nums del 1 al 100 son;
for i in {1..100}
do
	echo "$i";
done
exit 0;